#' @title Social Network Map
#' @description Takes RFID spatial matrices and Trapping data spatial matrices to map potential social interactions
#' @param g Trapping Matrix
#' @param sex_vec named vector linking sex to tracking ids
#' @param title title of the map
#' @keywords Trap, PPT
#' @export
#' @examples
#' \dontrun{
#' plot_panel(g_rfid, sex_vec, paste0(letters_row[1], "  RFID Data — ", enc_label)
#' }
