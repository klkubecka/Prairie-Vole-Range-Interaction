#' @title A social network matrix builder based on RFID data
#' @description This function lets you build a matrix that stored spatial data based on RFID data. this can then be used to create a social network map.
#' @param rfid_df Data frame containing RFID data
#' @param ids Tracking tag ID
#' @param window_s window frame in which tags are tracked around antenna
#' @keywords RFID
#' @export
#' @examples
#' \dontrun{
#'   rfid_build(rfid, ids_e, window_s = 300)
#' }
# building a custom function that builds a social network. defining the function name and the three inputs: rfid_df = full RFID data frame, ids = which animal detections to include, window_s = Time-bin width in seconds, set at 5 minutes to scan which two animals were scanned at the same antenna within a 5 minute window. Counting this as associating or pairing.
rfid_build <- function(rfid_df, ids, window_s = 300) {
  # subset of rfid data to only store tags in the ids list and then creating a bin converting the time stamp into a time-window number and then creating an event column to combine antenna and bin data. distinct(event, tag) collapses detections of the same individual into one row.
  sub <- rfid_df |>
    filter(tag %in% ids) |>
    mutate(bin   = as.integer(as.numeric(dt) %/% window_s),
           event = paste(antenna, bin, sep = "|")) |>
    distinct(event, tag)

  # Number of animals in the network
  N <- length(ids)

  # If there are zero rows this creates an empty grpah with N nodes and not edges.
  if (nrow(sub) == 0) {
    g <- make_empty_graph(n = N, directed = FALSE)
    V(g)$name <- ids # name the nodes so the grpah is still labeled.
    return(g)
  }

  events <- unique(sub$event) # pull out distinct event identifiers
  M <- matrix(0L, nrow = length(events), ncol = N,
              dimnames = list(events, ids))
  M[cbind(match(sub$event, events), match(sub$tag, ids))] <- 1L # allocating empty integer matrix and naming the rows (event id) and columns with the animal id.

  seen <- colSums(M) # total number of events an animal appeared in
  co <- crossprod(M) # matrix transpose times matrix to create a matrix where number of events at which both animals were detected.
  diag(co) <- 0 # set diagonals to 0 so no self loops are created

  denom <- outer(seen, seen, "+") - co # creating denominator for SRI creating matrix which generates the number of events at which at least one pair was present
  sri   <- ifelse(denom > 0, co / denom, 0) # guarding against division by 0
  diag(sri) <- 0 # again removing self loops
  dimnames(sri) <- list(ids, ids) # reattaching row and column names.

  graph_from_adjacency_matrix(sri, mode = "undirected",
                              weighted = TRUE, diag = FALSE) # Building and returning igraph object from SRI matrix.
}
