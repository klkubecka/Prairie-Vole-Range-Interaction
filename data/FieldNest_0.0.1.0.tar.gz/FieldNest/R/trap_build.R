#' @title A social network matrix builder based on trapping ppt data
#' @description This function lets you build a matrix that stored spatial data based on trapping ppt data. this can then be used to create a social network map.
#' @param pppt_df Trapping/ppt data frame
#' @param ids Tracking id tags
#' @keywords Trap, PPT
#' @export
#' @examples
#' \dontrun{
#' trap_build(pppt |> filter(Enclosure == enc_id), ids_e)
#' }

# Building a function that takes the trapping data and using it to create a social network.
trap_build <- function(pppt_df, ids) {
  edge_df <- pppt_df |>
    filter(Female %in% ids, Male %in% ids,
           !is.na(Trapping), Trapping > 0) |>
    transmute(from = Female, to = Male, weight = Trapping) # Start by building an edge list filtering rows where Female and Male are in the ids and Trapping is not NA and greater than 0. Then creating a new columns to be Female, Male, Trapping representing a weighted connection.

  vertex_df <- data.frame(name = ids) #Then creating a node list so all individual ids appear in the graph

  if (nrow(edge_df) == 0) {
    g <- make_empty_graph(n = length(ids), directed = FALSE)
    V(g)$name <- ids
    return(g)
  } # If no valid trapping is found creates and empty undirected graph

  graph_from_data_frame(edge_df, directed = FALSE, vertices = vertex_df)
} # build weighted graph using igraph function.
